Config = {}

Config.JailLocation = { x = 3553.75, y = 3685.20, z = 28.12 }

Config.ReleaseLocation = { x = 160.03, y = -1007.52, z = 29.51 }